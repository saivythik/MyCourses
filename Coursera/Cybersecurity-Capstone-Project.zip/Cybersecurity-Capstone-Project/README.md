
The project is hosted at and click this link: http://cs-capstone-chat.herokuapp.com/